package vn.salehunter.hasaki

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.net.URI

data class TrackedProduct(val url: String, val target: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SaleHunterScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaleHunterScreen() {
    var url by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val products = remember { mutableStateListOf<TrackedProduct>() }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF087F5B),
        secondary = androidx.compose.ui.graphics.Color(0xFF3B8C74)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("SALE HUNTER", fontWeight = FontWeight.Bold)
                            Text("HASAKI • ANDROID", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Theo dõi giá Hasaki", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Thêm link sản phẩm và mức giá bạn muốn mua.")
                            OutlinedTextField(
                                value = url, onValueChange = { url = it; error = "" },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Link sản phẩm Hasaki") },
                                placeholder = { Text("https://hasaki.vn/...") },
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = target, onValueChange = { target = it.filter(Char::isDigit) },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Giá mục tiêu (VNĐ)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                            Button(
                                onClick = {
                                    val host = runCatching { URI(url.trim()).host }.getOrNull()
                                    val price = target.toLongOrNull()
                                    if (host == null || !(host == "hasaki.vn" || host.endsWith(".hasaki.vn"))) {
                                        error = "Hãy nhập đường dẫn sản phẩm thuộc hasaki.vn."
                                    } else if (price == null || price <= 0) {
                                        error = "Hãy nhập giá mục tiêu hợp lệ."
                                    } else {
                                        products.add(TrackedProduct(url.trim(), price))
                                        url = ""; target = ""; error = ""
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("＋ Thêm sản phẩm") }
                        }
                    }
                }
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Bản khởi tạo • Chưa kết nối dữ liệu giá", fontWeight = FontWeight.Bold)
                            Text(
                                "Danh sách và giá mục tiêu hiện hoạt động ở mức giao diện. Cần kết nối nguồn giá được Hasaki cho phép trước khi bật theo dõi tự động và gửi Telegram.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Sản phẩm đang theo dõi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("${products.size}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
                if (products.isEmpty()) {
                    item {
                        Card(shape = RoundedCornerShape(16.dp)) {
                            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                Text("Chưa có sản phẩm. Dán link Hasaki ở phía trên để thêm.")
                            }
                        }
                    }
                } else {
                    items(products) { product ->
                        Card(shape = RoundedCornerShape(16.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text(product.url, style = MaterialTheme.typography.bodySmall)
                                    Text("Giá mục tiêu: ${"%,d".format(product.target)}đ", fontWeight = FontWeight.Bold)
                                    Text("Chờ kết nối nguồn giá", color = MaterialTheme.colorScheme.tertiary,
                                        style = MaterialTheme.typography.labelMedium)
                                }
                                IconButton(onClick = { products.remove(product) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Xóa sản phẩm")
                                }
                            }
                        }
                    }
                }
                item {
                    Text(
                        "An toàn: ứng dụng không tự đặt hàng hoặc thanh toán. Khi có ưu đãi, bạn sẽ tự kiểm tra và xác nhận mua.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
