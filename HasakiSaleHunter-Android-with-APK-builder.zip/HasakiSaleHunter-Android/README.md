# Hasaki Sale Hunter — Android starter (v0.1.0)

Đây là **bản khởi tạo giao diện Android**, chưa phải ứng dụng săn giá tự động hoàn chỉnh.

## Đã có
- Giao diện Android bằng Kotlin + Jetpack Compose.
- Thêm link sản phẩm thuộc `hasaki.vn`.
- Đặt giá mục tiêu VNĐ.
- Danh sách sản phẩm và xóa sản phẩm khỏi danh sách.

## Chưa có
- Chưa lấy giá trực tiếp từ Hasaki.
- Chưa có lịch chạy nền / kiểm tra giá.
- Chưa kết nối Telegram.
- Chưa có lịch sử giá và thông báo sale.

Lý do: Hasaki không công bố API phát triển công khai cho bên thứ ba. Cần nguồn dữ liệu được Hasaki cho phép hoặc một tích hợp hợp pháp trước khi triển khai bộ kiểm tra giá. Không dùng CAPTCHA bypass, né giới hạn truy cập hoặc đăng nhập tự động trái phép.

## Mở bằng Android Studio
1. Giải nén ZIP.
2. Mở thư mục `HasakiSaleHunter-Android` bằng Android Studio.
3. Chờ Gradle Sync.
4. Chạy trên máy Android hoặc emulator (Android 8.0 trở lên).

## Bước tiếp theo để bật Telegram
Cần tạo bot Telegram và lấy Bot Token + Chat ID. Không gửi token trong tin nhắn công khai hoặc đưa token vào mã nguồn. Bản hoàn chỉnh sẽ lưu thông tin nhạy cảm an toàn và chỉ gửi thông báo giá, không tự thanh toán.

## Công nghệ dự kiến cho bản hoàn chỉnh
- Android: Kotlin, Jetpack Compose, WorkManager.
- Backend: dịch vụ theo dõi giá chạy máy chủ (cần nguồn dữ liệu được cấp phép).
- Thông báo: Telegram Bot API.
- Lịch sử giá: SQLite/Room ở máy và cơ sở dữ liệu backend nếu cần.
